import React from "react";
import MotorcycleTyresPage from "./MotorcycleTyresPage";
import "./styles.css";

export default function App() {
  return <MotorcycleTyresPage />;
}